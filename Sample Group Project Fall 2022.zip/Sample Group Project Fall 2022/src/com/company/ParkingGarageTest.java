package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ParkingGarageTest {

    @Test
    void testSpot1() {
        ParkingGarage parkingGarage = new ParkingGarage();
        parkingGarage.addListener(new Customer());
        parkingGarage.addListener(new Customer());
        ParkingSpace parkingSpace =
                parkingGarage.TakeParkingSpace();
        assertTrue(parkingSpace.getName().equals("1"));

    }
    @Test
    void testTicketNumber() {
        TicketGenerator ticketGenerator = new TicketGenerator();
        ticketGenerator.getTicketNumber();
        TicketGenerator ticketGenerator1 = new TicketGenerator();
        int ticket =ticketGenerator1.getTicketNumber();
        assertTrue(ticket==2);

    }
}