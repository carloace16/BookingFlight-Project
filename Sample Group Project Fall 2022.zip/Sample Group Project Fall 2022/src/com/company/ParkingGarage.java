package com.company;

import java.util.ArrayList;
import java.util.List;

public class ParkingGarage {
    List<ParkingGarageListener> parkingGarageListeners = new ArrayList<>();
    public void addListener(ParkingGarageListener parkingGarageListener)
    {
        parkingGarageListeners.add(parkingGarageListener);
    }
    public void removeListener(ParkingGarageListener parkingGarageListener)
    {
        parkingGarageListeners.remove(parkingGarageListener);
    }
    public void notify(int numberOfOpenSpots)
    {
        for(ParkingGarageListener p :parkingGarageListeners)
            p.notify(numberOfOpenSpots);
    }
    List<ParkingSpace> openSpaces = new ArrayList<>();
    List<ParkingSpace> spaceTaken = new ArrayList<>();
    ParkingSpace TakeParkingSpace()
    {
        // get the firs open space
        ParkingSpace parkingSpace = openSpaces.get(0);
        openSpaces.remove(parkingSpace);
        spaceTaken.add(parkingSpace);
        notify(openSpaces.size() - spaceTaken.size());
        TicketGenerator ticketGenerator = new TicketGenerator();
        parkingSpace.setName(
                String.valueOf(ticketGenerator.getTicketNumber()));
        return parkingSpace;
    }
    ParkingGarage()
    {
        generateParkingSpots();
    }
    void generateParkingSpots()
    {
        for(int i =0; i< 50;i++)
            openSpaces.add(new ParkingSpace());
        System.out.println("generatig spaces");
    }
}
