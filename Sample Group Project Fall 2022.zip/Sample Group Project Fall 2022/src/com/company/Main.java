package com.company;

public class Main {

    public static void main(String[] args) {
	ParkingGarage parkingGarage = new ParkingGarage();
        parkingGarage.addListener(new Customer());
        parkingGarage.addListener(new Customer());
    ParkingSpace parkingSpace =
                parkingGarage.TakeParkingSpace();
    System.out.println("My spot is" + parkingSpace.getName());
    }
}
