package com.company;

public interface ParkingGarageListener {
    void notify(int numberOfOpenspots);

}
