package com.company;

public class TicketGenerator {
    static int ticketNumber = 0;
    int getTicketNumber()
    {
        ticketNumber++;
        return ticketNumber;
    }
}
