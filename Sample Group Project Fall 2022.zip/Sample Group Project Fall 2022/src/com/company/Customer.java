package com.company;

public class Customer implements ParkingGarageListener{
    @Override
    public void notify(int numberOfOpenspots) {
        System.out.println("number of open spots =" + numberOfOpenspots);
    }
}
